/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pila; 

public class Main {
    public static void main(String[] args) {
        // Creamos una pila de enteros
        Pila pila = new Pila();

        // Agregamos datos
        pila.push(10);
        pila.push(20);
        pila.push(30);

        // Mostramos el contenido
        pila.mostrar();

        // Mostramos el elemento superior
        System.out.println("Elemento en la cima: " + pila.peek());

        // Eliminamos un elemento
        pila.pop();

        // Mostramos el contenido nuevamente
        pila.mostrar();

        // Verificamos si está vacía
        System.out.println("¿Está vacía la pila? " + pila.estaVacia());
    }
}
