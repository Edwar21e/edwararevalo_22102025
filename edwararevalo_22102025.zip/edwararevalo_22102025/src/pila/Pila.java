/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pila; 

import java.util.ArrayList;

public class Pila {
    private ArrayList<Integer> elementos; // Lista que guarda los valores
    private int tope; // Índice del último elemento

    public Pila() {
        elementos = new ArrayList<>();
        tope = -1; // Pila vacía
    }

    // Agregar elemento (push)
    public void push(int valor) {
        elementos.add(valor);
        tope++;
        System.out.println("Se agregó el valor: " + valor);
    }

    // Eliminar elemento (pop)
    public Integer pop() {
        if (estaVacia()) {
            System.out.println("La pila está vacía. No se puede eliminar.");
            return null;
        } else {
            int valorEliminado = elementos.remove(tope);
            tope--;
            System.out.println("Se eliminó el valor: " + valorEliminado);
            return valorEliminado;
        }
    }

    // Mostrar el valor del tope (peek)
    public Integer peek() {
        if (estaVacia()) {
            System.out.println("La pila está vacía.");
            return null;
        } else {
            return elementos.get(tope);
        }
    }

    // Verificar si la pila está vacía
    public boolean estaVacia() {
        return tope == -1;
    }

    // Mostrar todos los datos de la pila
    public void mostrar() {
        if (estaVacia()) {
            System.out.println("La pila está vacía.");
        } else {
            System.out.println("Contenido de la pila:");
            for (int i = tope; i >= 0; i--) {
                System.out.println(elementos.get(i));
            }
        }
    }
}
